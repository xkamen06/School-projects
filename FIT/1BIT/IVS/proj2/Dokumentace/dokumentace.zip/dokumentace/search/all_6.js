var searchData=
[
  ['sqrt_5ff',['sqrt_f',['../mathematic__lib_8cpp.html#a98bc6df2071336626d6d8dbdc938c350',1,'sqrt_f(double a):&#160;mathematic_lib.cpp'],['../mathematic__lib_8h.html#a98bc6df2071336626d6d8dbdc938c350',1,'sqrt_f(double a):&#160;mathematic_lib.cpp']]],
  ['sub_5ff',['sub_f',['../mathematic__lib_8cpp.html#a17b07fd3582c3468286db9ee6baf2b71',1,'sub_f(double a, double b):&#160;mathematic_lib.cpp'],['../mathematic__lib_8h.html#a17b07fd3582c3468286db9ee6baf2b71',1,'sub_f(double a, double b):&#160;mathematic_lib.cpp']]]
];
