var searchData=
[
  ['pomocny',['pomocny',['../mainwindow_8cpp.html#a24ccfefad2482ef80f26b3e6cb48c54c',1,'mainwindow.cpp']]],
  ['proces',['proces',['../mainwindow_8cpp.html#ab0babfaa5e0e557030c900e41b835ea4',1,'mainwindow.cpp']]],
  ['prvninum',['prvniNum',['../mainwindow_8cpp.html#a73c696b32dca2016ba6374fb118d25f1',1,'mainwindow.cpp']]]
];
