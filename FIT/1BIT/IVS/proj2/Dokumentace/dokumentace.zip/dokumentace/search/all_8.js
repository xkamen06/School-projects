var searchData=
[
  ['ui_5fcalcvorez',['Ui_CalcVorez',['../classUi__CalcVorez.html',1,'']]]
];
