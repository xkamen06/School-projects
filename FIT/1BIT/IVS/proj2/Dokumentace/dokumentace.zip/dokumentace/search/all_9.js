var searchData=
[
  ['value',['value',['../mainwindow_8cpp.html#a0c0d1b18d3033cb858562e5e8636c18f',1,'mainwindow.cpp']]]
];
