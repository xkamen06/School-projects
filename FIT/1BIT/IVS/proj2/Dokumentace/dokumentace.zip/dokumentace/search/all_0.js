var searchData=
[
  ['add_5ff',['add_f',['../mathematic__lib_8cpp.html#a315d0932a6f42520b05d93f7f1579be8',1,'add_f(double a, double b):&#160;mathematic_lib.cpp'],['../mathematic__lib_8h.html#a315d0932a6f42520b05d93f7f1579be8',1,'add_f(double a, double b):&#160;mathematic_lib.cpp']]]
];
