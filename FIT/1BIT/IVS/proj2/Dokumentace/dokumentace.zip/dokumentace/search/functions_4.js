var searchData=
[
  ['pow_5ff',['pow_f',['../mathematic__lib_8cpp.html#aafe966c266cec1a9e46f3cc18b599e80',1,'pow_f(double a, int n):&#160;mathematic_lib.cpp'],['../mathematic__lib_8h.html#aafe966c266cec1a9e46f3cc18b599e80',1,'pow_f(double a, int n):&#160;mathematic_lib.cpp']]]
];
