var searchData=
[
  ['calcvorez',['CalcVorez',['../classUi_1_1CalcVorez.html',1,'Ui']]]
];
