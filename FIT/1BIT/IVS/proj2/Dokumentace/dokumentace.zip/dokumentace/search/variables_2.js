var searchData=
[
  ['total',['total',['../mainwindow_8cpp.html#a62d0e1710d446ae7d07c59c9f0703df7',1,'mainwindow.cpp']]]
];
