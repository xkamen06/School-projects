var searchData=
[
  ['druhynum',['druhyNum',['../mainwindow_8cpp.html#ac77f47a772fc9338f04d95836cc9aa44',1,'mainwindow.cpp']]],
  ['druhynum_5fint',['druhyNum_int',['../mainwindow_8cpp.html#a37eb6f9dcd85380f7652a19ba009de4f',1,'mainwindow.cpp']]]
];
